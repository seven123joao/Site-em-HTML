
<?php
$mensagem = "Bem-vindo(a) à SE7ES";
echo "<p>{$mensagem}</p>";
?>